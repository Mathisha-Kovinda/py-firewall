#!/bin/bash

# Function to check if a package is installed
is_installed() {
    rpm -q "$1" &> /dev/null
}

# Function to install a package if not already installed
install_package() {
    if is_installed "$1"; then
        echo "$1 is already installed."
    else
        sudo yum install -y "$1"
    fi
}

# Install Python 3 if not already installed
if ! command -v python3 &> /dev/null; then
    sudo yum install -y python3
else
    echo "Python 3 is already installed."
fi

# Install necessary system packages
install_package dbus-x11
install_package rsyslog

# Upgrade pip
python3 -m pip install --upgrade pip

# Install Python libraries
python3 -m pip install scapy
python3 -m pip install psutil
python3 -m pip install pyroute2

# Note: The following libraries are part of the Python standard library and do not need to be installed:
# time, subprocess, re, threading, sys, ipaddress

# Install tkinter (part of the python3-tkinter package)
install_package python3-tkinter

echo "All specified packages have been installed."

